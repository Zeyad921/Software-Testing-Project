package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pages.BasePage;

public class RegistrationSuccessPage extends BasePage {

    @FindBy(xpath = "//p[contains(text(), 'Your account was created successfully')]")
    private WebElement welcomeMessage;

    public RegistrationSuccessPage(WebDriver driver) {
        super(driver);
    }

    public boolean isSuccessMessageDisplayed() {
        return isElementDisplayed(welcomeMessage);
    }
}