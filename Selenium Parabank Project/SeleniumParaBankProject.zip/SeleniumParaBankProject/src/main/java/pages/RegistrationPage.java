package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage extends BasePage {

    @FindBy(id = "customer.firstName")
    private WebElement firstNameInput;

    @FindBy(id = "customer.lastName")
    private WebElement lastNameInput;

    @FindBy(id = "customer.address.street")
    private WebElement addressInput;

    @FindBy(id = "customer.address.city")
    private WebElement cityInput;

    @FindBy(id = "customer.address.state")
    private WebElement stateInput;

    @FindBy(id = "customer.address.zipCode")
    private WebElement zipCodeInput;

    @FindBy(id = "customer.phoneNumber")
    private WebElement phoneInput;

    @FindBy(id = "customer.ssn")
    private WebElement ssnInput;

    @FindBy(id = "customer.username")
    private WebElement usernameInput;

    @FindBy(id = "customer.password")
    private WebElement passwordInput;

    @FindBy(id = "repeatedPassword")
    private WebElement confirmPasswordInput;

    @FindBy(css = "input[value='Register']")
    private WebElement registerButton;

    // Error messages
    @FindBy(xpath = "//*[@id='customer.firstName.errors']")
    private WebElement firstNameError;

    @FindBy(xpath = "//*[@id='customer.username.errors']")
    private WebElement usernameError;

    public RegistrationPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Fills in registration form and submits it
     */
    public AccountOverviewPage register(
            String firstName, String lastName, String address,
            String city, String state, String zip,
            String phone, String ssn, String username,
            String password, String confirmPassword
    ) {
        sendKeys(firstNameInput, firstName);
        sendKeys(lastNameInput, lastName);
        sendKeys(addressInput, address);
        sendKeys(cityInput, city);
        sendKeys(stateInput, state);
        sendKeys(zipCodeInput, zip);
        sendKeys(phoneInput, phone);
        sendKeys(ssnInput, ssn);
        sendKeys(usernameInput, username);
        sendKeys(passwordInput, password);
        sendKeys(confirmPasswordInput, confirmPassword);
        click(registerButton);

        return new AccountOverviewPage(driver);
    }

    public boolean isRegistrationFormDisplayed() {
        return isElementDisplayed(firstNameInput);
    }

    public String getFirstNameError() {
        try {
            waitForElementVisibility(firstNameError);
            return firstNameError.getText().trim();
        } catch (Exception e) {
            return "";
        }
    }

    public String getUsernameError() {
        try {
            waitForElementVisibility(usernameError);
            return usernameError.getText().trim();
        } catch (Exception e) {
            return "";
        }
    }
}