package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LogoutPage extends BasePage {

    @FindBy(linkText = "Log Out")
    private WebElement logoutLink;

    @FindBy(name = "username")
    private WebElement usernameField;

    @FindBy(name = "password")
    private WebElement passwordField;

    public LogoutPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Clicks the logout link and returns to login page
     */
    public LoginPage performLogout() {
        wait.until(ExpectedConditions.elementToBeClickable(logoutLink)).click();
        return new LoginPage(driver);
    }

    /**
     * Verifies if logout was successful by checking login page elements
     */
    public boolean isOnLoginPage() {
        try {
            return wait.until(ExpectedConditions.visibilityOf(usernameField)).isDisplayed() &&
                    wait.until(ExpectedConditions.visibilityOf(passwordField)).isDisplayed();
        } catch (Exception e) {
            System.out.println("Error verifying logout: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if logout link is currently visible
     */
    public boolean isLogoutLinkDisplayed() {
        try {
            return logoutLink.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}