package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class AccountOverviewPage extends BasePage {

    @FindBy(linkText = "Log Out")
    private WebElement logoutLink;

    @FindBy(xpath = "//h1[@class='title']")
    private WebElement pageTitle;

    @FindBy(xpath = "//p[contains(text(), 'Your account was created successfully')]")
    private WebElement registrationSuccessMessage;

    @FindBy(id = "accountTable")
    private WebElement accountTable;

    @FindBy(xpath = "//table[@id='accountTable']//tr[1]//a")
    private WebElement firstAccountNumber;

    @FindBy(id = "leftPanel")
    private WebElement leftPanel;

    @FindBy(linkText = "Accounts Overview")
    private WebElement accountsOverviewLink;

    @FindBy(xpath = "//div[@id='rightPanel']//h1")
    private WebElement welcomeMessage;

    @FindBy(xpath = "//table[@id='accountTable']/tbody/tr")
    private List<WebElement> accountRows;

    public AccountOverviewPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Validates that the Accounts Overview page is loaded
     * Also accepts Account Details or Account Activity pages
     */
    public boolean isPageLoaded() {
        try {
            waitForElementVisibility(pageTitle);
            String title = getText(pageTitle);
            return (title.contains("Accounts Overview") ||
                    title.contains("Account Details") ||
                    title.contains("Account Activity"));
        } catch (Exception e) {
            System.out.println("Error checking if page is loaded: " + e.getMessage());
            return false;
        }
    }

    /**
     * Navigates to the Account Details by clicking the first account number
     * If already on account details page, returns new instance of AccountDetailsPage
     */
    public AccountDetailsPage clickFirstAccountNumber() {
        try {
            // If we're already on the Account Details or Activity page, just return it
            if (driver.getCurrentUrl().contains("activity.htm")) {
                return new AccountDetailsPage(driver);
            }

            // If we're on another page, navigate to Accounts Overview first
            if (!isElementDisplayed(accountTable)) {
                try {
                    waitForElementVisibility(accountsOverviewLink);
                    click(accountsOverviewLink);
                } catch (Exception e) {
                    System.out.println("Could not find Accounts Overview link, trying to continue...");
                }
            }

            // Find and click the first account number
            waitForElementVisibility(firstAccountNumber);
            click(firstAccountNumber);
            return new AccountDetailsPage(driver);
        } catch (Exception e) {
            System.out.println("Failed to click account number: " + e.getMessage());

            // As fallback: if we're already on an account page, return that
            if (driver.getCurrentUrl().contains("activity.htm")) {
                return new AccountDetailsPage(driver);
            }
            throw new RuntimeException("Failed to click account number", e);
        }
    }

    /**
     * Validates registration success message
     * Also checks if we're on a account page as alternative success indicator
     */
    public boolean isRegistrationSuccessMessageDisplayed() {
        try {
            // Check for success indicators - either message or being on account page
            if (driver.getCurrentUrl().contains("activity.htm") ||
                    driver.getCurrentUrl().contains("overview.htm")) {

                // If we're on the account page, then registration was successful
                return true;
            }

            // Also check for welcome message as an alternative indicator
            try {
                if (isElementDisplayed(welcomeMessage) &&
                        getText(welcomeMessage).contains("Welcome")) {
                    return true;
                }
            } catch (Exception ex) {
                // Continue checking other indicators
            }

            // Finally check for explicit success message
            return isElementDisplayed(registrationSuccessMessage);
        } catch (Exception e) {
            System.out.println("Error checking registration success: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if "Log Out" link is displayed
     */
    public boolean isLogoutLinkDisplayed() {
        try {
            waitForElementVisibility(leftPanel);

            // First check if we're on any valid logged-in page
            if (driver.getCurrentUrl().contains("parabank") &&
                    (driver.getCurrentUrl().contains("activity") ||
                            driver.getCurrentUrl().contains("overview") ||
                            driver.getCurrentUrl().contains("accounts"))) {

                // Then check for logout link
                return logoutLink.isDisplayed();
            }
            return false;
        } catch (Exception e) {
            System.out.println("Error checking for logout link: " + e.getMessage());
            return false;
        }
    }

    /**
     * Gets account number from URL or page text
     */
    public String getAccountNumberFromPage() {
        try {
            waitForElementVisibility(firstAccountNumber);
            return getText(firstAccountNumber);
        } catch (Exception e) {
            System.out.println("Could not get account number: " + e.getMessage());

            // Try to get it from URL if we're on account details page
            try {
                String url = driver.getCurrentUrl();
                if (url.contains("id=")) {
                    return url.substring(url.indexOf("id=") + 3);
                }
            } catch (Exception ex) {
                // Ignore and return empty
            }
            return "";
        }
    }

    /**
     * Verifies if transaction table is displayed
     */
    public boolean areTransactionsDisplayed() {
        try {
            // Check if we're on the account details page that has transactions
            if (driver.getCurrentUrl().contains("activity.htm")) {
                WebElement transactionTable = driver.findElement(By.xpath("//table[contains(@class, 'table') and .//th[contains(text(), 'Transaction')]]"));
                return transactionTable.isDisplayed();
            }

            // If on the overview page, check for account table
            return isElementDisplayed(accountTable);
        } catch (Exception e) {
            System.out.println("Error checking transactions: " + e.getMessage());
            return false;
        }
    }

    /**
     * Gets total balance (example: Total column)
     */
    public String getTotalBalance() {
        try {
            WebElement totalBalanceCell = driver.findElement(By.xpath("//td[contains(text(), 'Total')]//following-sibling::td[2]"));
            return getText(totalBalanceCell);
        } catch (Exception e) {
            System.out.println("Could not get total balance: " + e.getMessage());
            return "";
        }
    }

    /**
     * Checks if an account with the given ID is listed in the accounts table
     * Uses a more robust approach to find the account
     */
    /**
     * Checks if an account with the given ID is listed in the accounts table
     * @param accountId The account number to look for
     * @return true if account is found in the table, false otherwise
     */
    public boolean isAccountListed(String accountId) {
        try {
            // First wait for the table to be visible
            waitForElementVisibility(accountTable);

            // Check if we have any account rows loaded
            if (accountRows.isEmpty()) {
                System.out.println("No account rows found in the table");
                return false;
            }

            // Look for the account in the table rows
            for (WebElement row : accountRows) {
                try {
                    // Account number is typically in the first cell (td[1]) as a link
                    WebElement accountCell = row.findElement(By.xpath(".//td[1]"));
                    String currentAccountId = getText(accountCell).trim();

                    if (currentAccountId.equals(accountId)) {
                        return true;
                    }
                } catch (Exception e) {
                    // Skip this row if we can't read it
                    continue;
                }
            }

            // If not found in the rows, try a direct search as fallback
            try {
                WebElement accountLink = driver.findElement(
                        By.xpath("//table[@id='accountTable']//a[text()='" + accountId + "']"));
                return accountLink.isDisplayed();
            } catch (Exception e) {
                return false;
            }

        } catch (Exception e) {
            System.out.println("Error in isAccountListed(): " + e.getMessage());
            return false;
        }
    }

    /**
     * Gets all account IDs from the table
     */
    public List<String> getAllAccountIds() {
        List<String> accountIds = new ArrayList<>();
        try {
            waitForElementVisibility(accountTable);
            List<WebElement> accountLinks = driver.findElements(By.xpath("//table[@id='accountTable']//a"));
            for (WebElement link : accountLinks) {
                String id = getText(link);
                if (!id.isEmpty()) {
                    accountIds.add(id);
                }
            }
        } catch (Exception e) {
            System.out.println("Error getting all account IDs: " + e.getMessage());
        }
        return accountIds;
    }
    public BillPayPage clickBillPay() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement billPayLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Bill Pay")));
        billPayLink.click();
        return new BillPayPage(driver);
    }
    /**
     * Logs out of the application
     */
    public LoginPage logout() {
        click(logoutLink);
        return new LoginPage(driver);
    }


}