package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.BillPayPage ;
import java.time.Duration;

public class BillPayPage {
    private WebDriver driver;

    // ===== Locators =====
    private By payeeNameField = By.name("payee.name");
    private By addressField = By.name("payee.address.street");
    private By cityField = By.name("payee.address.city");
    private By stateField = By.name("payee.address.state");
    private By zipCodeField = By.name("payee.address.zipCode");
    private By phoneField = By.name("payee.phoneNumber");
    private By accountNumberField = By.name("payee.accountNumber");
    private By verifyAccountField = By.name("verifyAccount");
    private By amountField = By.name("amount");
    private By sendPaymentButton = By.cssSelector("input[value='Send Payment']");

    private By confirmationMessage = By.xpath("//*[contains(text(),'Bill Payment Complete')]");
    private By errorMessage = By.className("error"); // تأكد من الكلاس ده حسب الموقع

    // ===== Constructor =====
    public BillPayPage(WebDriver driver) {
        this.driver = driver;
    }

    // ===== Page Actions =====

    public boolean isPageLoaded() {
        return driver.getTitle().contains("Bill Payment");
    }

    public void fillBillPaymentForm(String name, String address, String city, String state,
                                    String zip, String phone, String account, String amount) {
        driver.findElement(payeeNameField).clear();
        driver.findElement(payeeNameField).sendKeys(name);

        driver.findElement(addressField).clear();
        driver.findElement(addressField).sendKeys(address);

        driver.findElement(cityField).clear();
        driver.findElement(cityField).sendKeys(city);

        driver.findElement(stateField).clear();
        driver.findElement(stateField).sendKeys(state);

        driver.findElement(zipCodeField).clear();
        driver.findElement(zipCodeField).sendKeys(zip);

        driver.findElement(phoneField).clear();
        driver.findElement(phoneField).sendKeys(phone);

        driver.findElement(accountNumberField).clear();
        driver.findElement(accountNumberField).sendKeys(account);

        driver.findElement(verifyAccountField).clear();
        driver.findElement(verifyAccountField).sendKeys(account); // نفس الرقم للتأكيد

        driver.findElement(amountField).clear();
        driver.findElement(amountField).sendKeys(amount);
    }

    public void submitPayment() {
        driver.findElement(sendPaymentButton).click();
    }


    public boolean isErrorMessageDisplayed() {
        return driver.findElements(errorMessage).size() > 0;
    }
    public String getConfirmationMessage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement confirmationHeader = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[@id='billpayResult']/h1")
        ));
        return confirmationHeader.getText();
    }

}
