package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import utils.Constants;

public class TransferFundsPage extends BasePage {

    // Locators - Updated with more specific locators
    @FindBy(id = "amount")
    private WebElement amountInput;

    @FindBy(id = "fromAccountId")
    private WebElement fromAccountDropdown;

    @FindBy(id = "toAccountId")
    private WebElement toAccountDropdown;

    // Updated with more specific locator
    @FindBy(xpath = "//*[@id='transferForm']/div[2]/input[@value='Transfer']")
    private WebElement transferButton;

    @FindBy(xpath = "//*[@id='showResult']/h1[text()='Transfer Complete!']")
    private WebElement successMessage;

    // Updated error message locators
    @FindBy(xpath = "//*[@id='showError']/h1[text()='Error!']")
    private WebElement errorHeader;

    @FindBy(xpath = "//*[@id='showError']/p[@class='error']")
    private WebElement errorMessage;

    @FindBy(xpath = "//div[@id='transferForm']//p[contains(@class,'error')]")
    private WebElement validationError;

    public TransferFundsPage(WebDriver driver) {
        super(driver);
    }

    public void waitUntilPageIsReady() {
        try {
            wait.until(ExpectedConditions.visibilityOf(amountInput));
            wait.until(ExpectedConditions.elementToBeClickable(amountInput));
            wait.until(ExpectedConditions.visibilityOf(fromAccountDropdown));
            wait.until(ExpectedConditions.elementToBeClickable(toAccountDropdown));
            wait.until(ExpectedConditions.visibilityOf(transferButton));
        } catch (TimeoutException e) {
            throw new RuntimeException("Transfer page elements not ready within timeout period", e);
        }
    }

    public void transferFunds(String amount, String fromAccount, String toAccount) {
        waitUntilPageIsReady();

        // Enter amount with validation
        clearAndType(amountInput, amount, "Amount field");

        // Select accounts with validation
        selectAccount(fromAccountDropdown, fromAccount, "From account");
        selectAccount(toAccountDropdown, toAccount, "To account");

        // Click transfer with enhanced reliability
        clickTransferButtonEnhanced();

        // Wait for transfer to complete
        waitForTransferResult();
    }

    private void clearAndType(WebElement element, String text, String fieldName) {
        try {
            element.clear();
            element.sendKeys(text);
            System.out.println("Successfully entered " + text + " in " + fieldName);
        } catch (Exception e) {
            throw new RuntimeException("Failed to enter text in " + fieldName + ": " + e.getMessage());
        }
    }

    private void selectAccount(WebElement dropdown, String accountNumber, String accountType) {
        try {
            Select select = new Select(dropdown);
            select.selectByValue(accountNumber);
            System.out.println("Successfully selected " + accountNumber + " for " + accountType);
        } catch (NoSuchElementException e) {
            throw new RuntimeException(accountType + " " + accountNumber + " not found in dropdown");
        } catch (Exception e) {
            throw new RuntimeException("Failed to select " + accountType + ": " + e.getMessage());
        }
    }

    // Enhanced click method with debug information
    private void clickTransferButtonEnhanced() {
        try {
            System.out.println("Attempting to click Transfer button");

            // Debug information
            System.out.println("Transfer button state: Displayed=" + transferButton.isDisplayed() +
                    ", Enabled=" + transferButton.isEnabled());

            // Ensure element is in viewport
            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView({block: 'center', inline: 'center'});",
                    transferButton
            );

            // Wait specifically for button to be clickable
            wait.until(ExpectedConditions.elementToBeClickable(transferButton));

            try {
                // Try regular click first
                System.out.println("Attempting standard click");
                transferButton.click();
                System.out.println("Standard click succeeded");
            } catch (ElementClickInterceptedException e) {
                // Fallback to JavaScript click
                System.out.println("Standard click failed, trying JavaScript click");
                ((JavascriptExecutor) driver).executeScript(
                        "arguments[0].click();",
                        transferButton
                );
                System.out.println("JavaScript click executed");
            }

            // Additional fallback if needed
            try {
                // Check if we're still on the same page
                boolean stillOnTransferPage = driver.getCurrentUrl().contains("/transfer.htm");
                if (stillOnTransferPage) {
                    System.out.println("Still on transfer page, trying additional click method");
                    // Try another approach with Actions
                    org.openqa.selenium.interactions.Actions actions = new org.openqa.selenium.interactions.Actions(driver);
                    actions.moveToElement(transferButton).click().build().perform();
                    System.out.println("Actions click executed");
                }
            } catch (Exception e) {
                System.out.println("Additional click attempt failed: " + e.getMessage());
            }

        } catch (Exception e) {
            System.out.println("Failed to click Transfer button: " + e.getMessage());
            throw new RuntimeException("Failed to click Transfer button: " + e.getMessage());
        }
    }

    private void waitForTransferResult() {
        try {
            System.out.println("Waiting for transfer result...");
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.visibilityOf(successMessage),
                    ExpectedConditions.visibilityOf(errorHeader),
                    ExpectedConditions.visibilityOf(errorMessage),
                    ExpectedConditions.visibilityOf(validationError)
            ));
            System.out.println("Transfer result appeared");

            // If transfer successful, log the result details
            if (isElementDisplayed(successMessage)) {
                System.out.println("SUCCESS: " + successMessage.getText());
                try {
                    WebElement amountResult = driver.findElement(By.id("amountResult"));
                    WebElement fromAccountResult = driver.findElement(By.id("fromAccountIdResult"));
                    WebElement toAccountResult = driver.findElement(By.id("toAccountIdResult"));

                    System.out.println("Transfer details: " + amountResult.getText() +
                            " from account #" + fromAccountResult.getText() +
                            " to account #" + toAccountResult.getText());
                } catch (Exception e) {
                    System.out.println("Could not read transfer details: " + e.getMessage());
                }
            }
            // If error occurred, log the error message
            else if (isElementDisplayed(errorHeader) || isElementDisplayed(errorMessage)) {
                System.out.println("ERROR detected!");
                if (isElementDisplayed(errorHeader)) {
                    System.out.println("Error header: " + errorHeader.getText());
                }
                if (isElementDisplayed(errorMessage)) {
                    System.out.println("Error message: " + errorMessage.getText());
                }
            }
        } catch (TimeoutException e) {
            System.out.println("Transfer result did not appear within timeout period");
            throw new RuntimeException("Transfer result did not appear within timeout period");
        }
    }

    public void clickTransferWithoutData() {
        waitUntilPageIsReady();
        clickTransferButtonEnhanced();
    }

    public boolean isTransferSuccessMessageDisplayed() {
        try {
            return successMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            System.out.println("Success message element not found");
            // Try alternative approach - check if page contains completion text
            try {
                return driver.getPageSource().contains("Transfer Complete") ||
                        driver.getPageSource().contains("has been transferred");
            } catch (Exception ex) {
                System.out.println("Failed to check page source: " + ex.getMessage());
                return false;
            }
        }
    }

    public boolean verifyTransferDetails(String expectedAmount, String fromAccount, String toAccount) {
        try {
            WebElement amountResult = driver.findElement(By.id("amountResult"));
            WebElement fromAccountResult = driver.findElement(By.id("fromAccountIdResult"));
            WebElement toAccountResult = driver.findElement(By.id("toAccountIdResult"));

            String actualAmount = amountResult.getText().replace("$", "").trim();
            String actualFromAccount = fromAccountResult.getText().trim();
            String actualToAccount = toAccountResult.getText().trim();

            System.out.println("Verifying transfer details:");
            System.out.println("Amount - Expected: " + expectedAmount + ", Actual: " + actualAmount);
            System.out.println("From Account - Expected: " + fromAccount + ", Actual: " + actualFromAccount);
            System.out.println("To Account - Expected: " + toAccount + ", Actual: " + actualToAccount);

            boolean amountMatches = actualAmount.equals(expectedAmount) ||
                    actualAmount.equals(expectedAmount + ".00");
            boolean fromAccountMatches = actualFromAccount.equals(fromAccount);
            boolean toAccountMatches = actualToAccount.equals(toAccount);

            return amountMatches && fromAccountMatches && toAccountMatches;
        } catch (Exception e) {
            System.out.println("Failed to verify transfer details: " + e.getMessage());
            return false;
        }
    }

    public String getTransferResultText() {
        try {
            if (isElementDisplayed(successMessage)) {
                return successMessage.getText();
            } else if (isElementDisplayed(errorHeader)) {
                String errorText = errorHeader.getText();
                if (isElementDisplayed(errorMessage)) {
                    errorText += " - " + errorMessage.getText();
                }
                return errorText;
            } else if (isElementDisplayed(errorMessage)) {
                return errorMessage.getText();
            } else if (isElementDisplayed(validationError)) {
                return validationError.getText();
            }
            return "No result message found";
        } catch (Exception e) {
            return "Error retrieving result: " + e.getMessage();
        }
    }

    public boolean isErrorDisplayed() {
        try {
            return isElementDisplayed(errorHeader) ||
                    (isElementDisplayed(errorMessage) && !isElementDisplayed(successMessage));
        } catch (Exception e) {
            System.out.println("Error checking for error message: " + e.getMessage());
            return false;
        }
    }

    public String getErrorMessage() {
        try {
            if (isElementDisplayed(errorMessage)) {
                return errorMessage.getText();
            } else if (isElementDisplayed(validationError)) {
                return validationError.getText();
            }
            return "";
        } catch (Exception e) {
            return "Error retrieving error message: " + e.getMessage();
        }
    }

    public String getValidationErrors() {
        try {
            return validationError.isDisplayed() ?
                    validationError.getText().toLowerCase() :
                    "";
        } catch (Exception e) {
            return "Error retrieving validation messages: " + e.getMessage();
        }
    }

    public void goToTransferPage() {
        driver.get(Constants.TRANSFER_FUNDS_URL);
        waitUntilPageIsReady();
    }

    // Enhanced debugging method
    public void logPageState() {
        try {
            System.out.println("=== Transfer Page State ===");
            System.out.println("Current URL: " + driver.getCurrentUrl());
            System.out.println("Amount field present: " + isElementDisplayed(amountInput));
            if (isElementDisplayed(amountInput)) {
                System.out.println("Amount field value: " + amountInput.getAttribute("value"));
            }

            System.out.println("From account dropdown present: " + isElementDisplayed(fromAccountDropdown));
            if (isElementDisplayed(fromAccountDropdown)) {
                System.out.println("From account: " + new Select(fromAccountDropdown).getFirstSelectedOption().getText());
            }

            System.out.println("To account dropdown present: " + isElementDisplayed(toAccountDropdown));
            if (isElementDisplayed(toAccountDropdown)) {
                System.out.println("To account: " + new Select(toAccountDropdown).getFirstSelectedOption().getText());
            }

            System.out.println("Transfer button present: " + isElementDisplayed(transferButton));
            if (isElementDisplayed(transferButton)) {
                System.out.println("Transfer button enabled: " + transferButton.isEnabled());
            }

            // Take screenshot for debugging
            try {
                TakesScreenshot ts = (TakesScreenshot) driver;
                String screenshot = ts.getScreenshotAs(OutputType.BASE64);
                System.out.println("Screenshot taken for debugging");
            } catch (Exception e) {
                System.out.println("Unable to take screenshot: " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Error while logging page state: " + e.getMessage());
        }
    }


}