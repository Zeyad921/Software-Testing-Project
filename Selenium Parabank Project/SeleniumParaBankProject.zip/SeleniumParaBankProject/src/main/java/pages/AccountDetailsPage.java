package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class AccountDetailsPage extends BasePage {

    @FindBy(xpath = "//h1[@class='title']")
    private WebElement pageTitle;

    @FindBy(id = "transactionTable")
    private WebElement transactionTable;

    @FindBy(xpath = "//span[@id='accountId']")
    private WebElement accountNumberLabel;

    @FindBy(xpath = "//a[contains(text(), 'Check # 1111')]")
    private WebElement checkTransaction;

    @FindBy(xpath = "//table[contains(@class, 'table')]")
    private WebElement activityTable;

    public AccountDetailsPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Validates that the Account Details or Activity page has loaded
     */
    public boolean isPageLoaded() {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(15))
                    .until(ExpectedConditions.or(
                            ExpectedConditions.urlContains("activity.htm"),
                            ExpectedConditions.visibilityOf(pageTitle)
                    ));

            // Accept either Account Activity or Account Details titles
            if (pageTitle.isDisplayed()) {
                String title = pageTitle.getText().trim();
                return title.contains("Account Activity") ||
                        title.contains("Account Details");
            }

            // If we're on the activity page URL, consider it loaded
            return driver.getCurrentUrl().contains("activity.htm");
        } catch (Exception e) {
            System.out.println("Error checking if account details page is loaded: " + e.getMessage());
            return false;
        }
    }

    /**
     * Get account number from page or URL
     */
    public String getAccountNumberFromPage() {
        try {
            // Check if account number is explicitly shown on page
            try {
                WebElement accountNumber = driver.findElement(
                        By.xpath("//span[contains(text(), 'Account Number:')]/following-sibling::span"));
                return accountNumber.getText().trim();
            } catch (Exception e) {
                // If not found on page, extract from URL
                String url = driver.getCurrentUrl();
                if (url.contains("id=")) {
                    return url.substring(url.indexOf("id=") + 3);
                }
            }
            return "";
        } catch (Exception e) {
            System.out.println("Error getting account number: " + e.getMessage());
            return "";
        }
    }

    /**
     * Checks if transaction table is displayed
     */
    public boolean areTransactionsDisplayed() {
        try {
            // Wait for any transaction-related table to be visible
            new WebDriverWait(driver, Duration.ofSeconds(10))
                    .until(ExpectedConditions.or(
                            ExpectedConditions.visibilityOf(activityTable),
                            ExpectedConditions.visibilityOf(transactionTable)
                    ));

            // Check if either table is displayed
            return isElementDisplayed(activityTable) || isElementDisplayed(transactionTable);
        } catch (Exception e) {
            System.out.println("Error checking for transaction table: " + e.getMessage());
            return false;
        }
    }

    /**
     * Verifies a specific transaction exists
     */
    public boolean verifySpecificTransactionExists(String transactionText) {
        try {
            List<WebElement> transactions = driver.findElements(
                    By.xpath("//td[contains(text(), '" + transactionText + "')]"));

            if (!transactions.isEmpty()) {
                return true;
            }

            // Also check for links that might contain the transaction text
            transactions = driver.findElements(
                    By.xpath("//a[contains(text(), '" + transactionText + "')]"));

            return !transactions.isEmpty();
        } catch (Exception e) {
            System.out.println("Error verifying transaction: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if a specific transaction is present
     */
    public boolean isTransactionPresent(String transactionText) {
        try {
            // First look for links with the transaction text
            try {
                List<WebElement> links = driver.findElements(
                        By.xpath("//a[contains(text(), '" + transactionText + "')]"));
                if (!links.isEmpty()) {
                    return true;
                }
            } catch (Exception e) {
                // Continue to next check
            }

            // Next look for table cells with the transaction text
            try {
                List<WebElement> cells = driver.findElements(
                        By.xpath("//td[contains(text(), '" + transactionText + "')]"));
                if (!cells.isEmpty()) {
                    return true;
                }
            } catch (Exception e) {
                // Continue to next check
            }

            // Look at the transaction table for any row containing the text
            try {
                return driver.findElement(
                                By.xpath("//table[contains(@class, 'table')]//tr[contains(., '" + transactionText + "')]"))
                        .isDisplayed();
            } catch (Exception e) {
                // All checks failed
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error checking for transaction: " + e.getMessage());
            return false;
        }
    }
}