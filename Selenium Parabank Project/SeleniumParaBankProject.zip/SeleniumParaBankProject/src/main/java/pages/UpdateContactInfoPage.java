package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class UpdateContactInfoPage extends BasePage {

    @FindBy(id = "customer.address.street")
    private WebElement addressField;

    @FindBy(id = "customer.address.city")
    private WebElement cityField;

    @FindBy(id = "customer.address.state")
    private WebElement stateField;

    @FindBy(id = "customer.address.zipCode")
    private WebElement zipCodeField;

    @FindBy(id = "customer.phoneNumber")
    private WebElement phoneField;

    @FindBy(css = "input[value='Update Profile']")
    private WebElement updateButton;

    @FindBy(xpath = "//*[@id=\"updateProfileResult\"]/h1")
    private WebElement successMessageH1;

    @FindBy(xpath = "//*[@id=\"updateProfileResult\"]/p")
    private WebElement successMessageP;

    @FindBy(xpath = "//*[@id=\"street-error\"]")
    private WebElement validationMessage;

    public UpdateContactInfoPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public boolean isPageLoaded() {
        return driver.getTitle().contains("Update Profile");
    }

    public void updateContactInfo(String address, String city, String state, String zipCode, String phone) {
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOf(addressField));

        addressField.clear(); addressField.sendKeys(address);
        cityField.clear(); cityField.sendKeys(city);
        stateField.clear(); stateField.sendKeys(state);
        zipCodeField.clear(); zipCodeField.sendKeys(zipCode);
        phoneField.clear(); phoneField.sendKeys(phone);
        updateButton.click();
    }

    public boolean isUpdateSuccessMessageDisplayed() {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(10))
                    .until(ExpectedConditions.or(
                            ExpectedConditions.visibilityOf(successMessageH1),
                            ExpectedConditions.visibilityOf(successMessageP)
                    ));

            return (successMessageH1.isDisplayed() && successMessageH1.getText().contains("Profile Updated")) ||
                    (successMessageP.isDisplayed() && successMessageP.getText().contains("Your updated address and phone number have been added to the system."));
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isValidationMessageDisplayed() {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(10))
                    .until(ExpectedConditions.visibilityOf(validationMessage));
            return validationMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}