package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class OpenAccountPage extends BasePage {

    @FindBy(id = "type")
    private WebElement accountTypeDropdown;

    @FindBy(id = "fromAccountId")
    private WebElement fromAccountDropdown;

    @FindBy(xpath = "//input[@value='Open New Account']")
    private WebElement openNewAccountButton;

    // Updated success message locators to match what's on the page
    @FindBy(xpath = "//h1[contains(text(),'Account Opened')]")
    private WebElement accountOpenedHeader;

    @FindBy(xpath = "//*[contains(text(),'Congratulations')]")
    private WebElement congratsMessage;

    @FindBy(xpath = "//*[contains(text(),'Your new account number')]")
    private WebElement accountNumberLabel;

    @FindBy(xpath = "//h1[@class='title']")
    private WebElement pageTitle;

    // Updated account ID locator with fallback options
    @FindBy(id = "newAccountId")
    private WebElement newAccountId;

    @FindBy(xpath = "//a[contains(@id, 'accountId')]")
    private WebElement accountIdLink;

    public OpenAccountPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Select an option from a dropdown by value or visible text.
     */
    private void selectDropdownOption(WebElement dropdown, String option) {
        waitForElementVisibility(dropdown);
        Select select = new Select(dropdown);

        try {
            // Try selecting by value first
            select.selectByValue(option);
        } catch (Exception e) {
            System.out.println("Could not select by value: " + e.getMessage() + ", trying by visible text...");
            // Try selecting by visible text if value selection fails
            select.selectByVisibleText(option);
        }
    }

    /**
     * Waits for and selects the account type (CHECKING or SAVINGS)
     */
    public void selectAccountType(String type) {
        String value = "0"; // default CHECKING
        if ("SAVINGS".equalsIgnoreCase(type)) {
            value = "1";
        }
        selectDropdownOption(accountTypeDropdown, value);
    }

    /**
     * Selects the source account for transferring funds
     */
    public void selectFromAccount(String accountId) {
        waitForElementVisibility(fromAccountDropdown);
        // Debugging log (optional)
        logAvailableAccountOptions(fromAccountDropdown);
        selectDropdownOption(fromAccountDropdown, accountId);
    }

    /**
     * Logs available options for debugging purposes.
     */
    private void logAvailableAccountOptions(WebElement dropdown) {
        Select select = new Select(dropdown);
        List<WebElement> options = select.getOptions();
        System.out.println("Available Account IDs:");
        for (WebElement option : options) {
            System.out.println(" - " + option.getAttribute("value") + ": " + option.getText());
        }
    }

    /**
     * Clicks "Open New Account" button
     */
    public void clickOpenNewAccount() {
        waitForElementClickable(openNewAccountButton);
        click(openNewAccountButton);
    }

    /**
     * Validates if success message is displayed - using multiple possible elements
     */
    public boolean isAccountOpenedSuccessfully() {
        return isElementDisplayed(accountOpenedHeader) ||
                isElementDisplayed(congratsMessage) ||
                isElementDisplayed(accountNumberLabel);
    }

    /**
     * Gets the ID of the newly created account with fallback methods
     */
    public String getNewAccountId() {
        try {
            // Try primary method first
            if (isElementDisplayed(newAccountId)) {
                String id = getText(newAccountId);
                System.out.println("Retrieved new account ID (method 1): " + id);
                return id;
            }

            // Try alternate account ID link
            if (isElementDisplayed(accountIdLink)) {
                String id = getText(accountIdLink);
                System.out.println("Retrieved new account ID (method 2): " + id);
                return id;
            }

            // Fallback: extract from page text if the account number is displayed in text
            String pageText = driver.getPageSource();
            if (pageText.contains("Your new account number:")) {
                String[] parts = pageText.split("Your new account number:");
                if (parts.length > 1) {
                    String extractedId = parts[1].trim().split("\\s+")[0].replaceAll("[^0-9]", "");
                    System.out.println("Retrieved new account ID (method 3): " + extractedId);
                    return extractedId;
                }
            }

            System.out.println("Failed to retrieve account ID through any method");
            return "";
        } catch (Exception e) {
            System.out.println("Error getting new account ID: " + e.getMessage());
            return "";
        }
    }

    /**
     * Validates that the Open Account page has loaded
     */
    public boolean isPageLoaded() {
        try {
            waitForElementVisibility(pageTitle);
            return pageTitle.isDisplayed() && getText(pageTitle).contains("Open");
        } catch (Exception e) {
            System.out.println("Error checking if Open Account page is loaded: " + e.getMessage());
            return false;
        }
    }

    /**
     * Opens a new account with the specified type and from account
     * @return The ID of the newly created account
     */
    public String openNewAccount(String accountType, String fromAccountNumber) {
        // Select account type (CHECKING or SAVINGS)
        selectAccountType(accountType);

        // Select the account to transfer funds from
        selectFromAccount(fromAccountNumber);

        // Click the Open New Account button
        clickOpenNewAccount();

        // Wait for success elements and capture the new account ID
        try {
            // Wait for any of the success indicators
            if (isAccountOpenedSuccessfully()) {
                return getNewAccountId();
            } else {
                System.out.println("Success message not found after opening account");
                return "";
            }
        } catch (Exception e) {
            System.out.println("Error during account opening process: " + e.getMessage());
            return "";
        }
    }

    /**
     * Gets the success message text by combining all possible success elements
     */
    public String getSuccessMessageText() {
        StringBuilder message = new StringBuilder();

        if (isElementDisplayed(accountOpenedHeader)) {
            message.append(getText(accountOpenedHeader)).append(" ");
        }

        if (isElementDisplayed(congratsMessage)) {
            message.append(getText(congratsMessage)).append(" ");
        }

        if (isElementDisplayed(accountNumberLabel)) {
            message.append(getText(accountNumberLabel));
        }

        // If no specific elements found, try getting text from the entire right panel
        if (message.length() == 0) {
            try {
                WebElement rightPanel = driver.findElement(org.openqa.selenium.By.id("rightPanel"));
                message.append(getText(rightPanel));
            } catch (Exception e) {
                System.out.println("Could not find right panel: " + e.getMessage());
            }
        }

        return message.toString().trim();
    }
}