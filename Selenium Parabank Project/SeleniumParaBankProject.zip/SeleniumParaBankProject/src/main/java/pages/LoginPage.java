package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage {

    @FindBy(name = "username")
    private WebElement usernameField;

    @FindBy(name = "password")
    private WebElement passwordField;

    @FindBy(xpath = "//input[@value='Log In']")
    private WebElement loginButton;

    @FindBy(linkText = "Register")
    private WebElement registerLink;

    @FindBy(xpath = "//p[@class='error']")
    private WebElement errorMessage;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public boolean isUsernameFieldDisplayed() {
        return isElementDisplayed(usernameField);
    }

    public boolean isPasswordFieldDisplayed() {
        return isElementDisplayed(passwordField);
    }

    public void enterUsername(String username) {
        sendKeys(usernameField, username);
    }

    public void enterPassword(String password) {
        sendKeys(passwordField, password);
    }

    public void clickLoginButton() {
        click(loginButton);
    }

    public AccountOverviewPage loginSuccessfully(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
        return new AccountOverviewPage(driver);
    }

    public LoginPage loginWithInvalidCredentials(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
        return this;
    }

    public boolean verifyTextContainsError(String expectedText) {
        try {
            String errorText = getErrorText().toLowerCase();
            return errorText.contains(expectedText.toLowerCase());
        } catch (Exception e) {
            return false;
        }
    }

    public String getErrorText() {
        try {
            waitForElementVisibility(errorMessage);
            return getText(errorMessage);
        } catch (Exception e) {
            return "";
        }
    }

    public RegistrationPage navigateToRegistration() {
        click(registerLink);
        return new RegistrationPage(driver);
    }
}