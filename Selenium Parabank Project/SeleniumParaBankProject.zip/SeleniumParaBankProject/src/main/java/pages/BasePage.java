package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import utils.Constants;

public class BasePage {
    protected WebDriver driver;
    protected WebDriverWait wait;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(Constants.EXPLICIT_WAIT));
        PageFactory.initElements(driver, this);
    }

    /**
     * Wait for an element to be visible
     */
    protected WebElement waitForElementVisibility(WebElement element) {
        try {
            return wait.until(ExpectedConditions.visibilityOf(element));
        } catch (Exception e) {
            System.out.println("Error waiting for element visibility: " + e.getMessage());
            return element;
        }
    }

    /**
     * Wait for an element to be visible with custom timeout
     */
    protected WebElement waitForElementVisibility(WebElement element, long timeoutInSeconds) {
        try {
            WebDriverWait customWait = new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds));
            return customWait.until(ExpectedConditions.visibilityOf(element));
        } catch (Exception e) {
            System.out.println("Error waiting for element visibility with timeout: " + e.getMessage());
            return element;
        }
    }

    /**
     * Wait for an element to be clickable
     */
    protected WebElement waitForElementClickable(WebElement element) {
        try {
            return wait.until(ExpectedConditions.elementToBeClickable(element));
        } catch (Exception e) {
            System.out.println("Error waiting for element to be clickable: " + e.getMessage());
            return element;
        }
    }

    /**
     * Alias for waitForElementClickable for compatibility
     */
    protected WebElement waitForElementToBeClickable(WebElement element) {
        return waitForElementClickable(element);
    }

    /**
     * Check if element is displayed with improved handling
     */
    protected boolean isElementDisplayed(WebElement element) {
        try {
            int attempts = 0;
            while (attempts < 3) {
                try {
                    return waitForElementVisibility(element).isDisplayed();
                } catch (Exception e) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ignored) {}
                }
                attempts++;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Safe click operation with retry logic and logging
     */
    protected void click(WebElement element) {
        int attempts = 0;
        while (attempts < 3) {
            try {
                waitForElementClickable(element).click();
                return;
            } catch (Exception e) {
                System.out.println("Click failed on attempt " + (attempts + 1) + ", retrying... " + e.getMessage());
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ignored) {}
                attempts++;
            }
        }
        // One last attempt directly
        try {
            element.click();
        } catch (Exception e) {
            System.out.println("Final click attempt failed: " + e.getMessage());
        }
    }

    /**
     * Safe text input with wait and retry logic
     */
    protected void sendKeys(WebElement element, String text) {
        int attempts = 0;
        while (attempts < 3) {
            try {
                WebElement visibleElement = waitForElementVisibility(element);
                visibleElement.clear();
                visibleElement.sendKeys(text);
                return;
            } catch (Exception e) {
                System.out.println("SendKeys failed on attempt " + (attempts + 1) + ", retrying... " + e.getMessage());
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ignored) {}
                attempts++;
            }
        }
    }

    /**
     * Select from dropdown with fallback to visible text
     */
    protected void select(WebElement dropdown, String value) {
        try {
            waitForElementVisibility(dropdown);
            Select select = new Select(dropdown);
            try {
                select.selectByValue(value);
            } catch (Exception e) {
                // Fallback: Try selecting by visible text
                select.selectByVisibleText(value);
            }
        } catch (Exception e) {
            System.out.println("Select operation failed: " + e.getMessage());
        }
    }

    /**
     * Select by value from dropdown
     */
    protected void selectByValue(WebElement dropdownElement, String value) {
        try {
            Select select = new Select(dropdownElement);
            select.selectByValue(value);
        } catch (Exception e) {
            System.out.println("SelectByValue failed: " + e.getMessage());
        }
    }

    /**
     * Get text with retry logic
     */
    protected String getText(WebElement element) {
        int attempts = 0;
        while (attempts < 5) {
            try {
                waitForElementVisibility(element);
                return element.getText().trim();
            } catch (Exception e) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ignored) {}
            }
            attempts++;
        }
        return "";
    }

    /**
     * Validates text directly with retry and contains match
     */
    protected boolean verifyTextContains(WebElement element, String expectedText) {
        String actualText = getText(element).toLowerCase();
        int attempts = 0;
        while (attempts < 5) {
            if (actualText.contains(expectedText.toLowerCase())) {
                return true;
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ignored) {}
            actualText = getText(element);
            attempts++;
        }
        return false;
    }

    /**
     * Ensures that the WebDriver quits after all tests
     */
    public void quitDriver() {
        if (driver != null) {
            driver.quit();
        }
    }
}
