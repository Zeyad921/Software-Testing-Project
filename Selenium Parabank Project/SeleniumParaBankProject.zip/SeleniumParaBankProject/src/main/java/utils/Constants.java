package utils;

public class Constants {

    // URLs - Fixed trailing whitespace issues
    public static final String BASE_URL = "https://parabank.parasoft.com/parabank/index.htm";
    public static final String REGISTER_URL = "https://parabank.parasoft.com/parabank/register.htm";
    public static final String TRANSFER_FUNDS_URL = "https://parabank.parasoft.com/parabank/transfer.htm";
    public static final String OPEN_ACCOUNT_URL = "https://parabank.parasoft.com/parabank/openaccount.htm"; // Removed trailing space
    public static final String ACCOUNTS_OVERVIEW_URL = "https://parabank.parasoft.com/parabank/overview.htm"; // Removed trailing space


    // Login Credentials
    public static final String VALID_USERNAME = "john";
    public static final String VALID_PASSWORD = "demo";
    public static final String VALID_USERNAME_ALT = "zeyad123";
    public static final String VALID_PASSWORD_ALT = "zeyad123456";

    public static final String INVALID_USERNAME = "zeyad@123";
    public static final String INVALID_PASSWORD = "123";

    // Error Messages (Matches actual UI)
    public static final String ERROR_MESSAGE = "The username and password could not be verified.";
    public static final String INVALID_CREDENTIALS_ERROR = "The username and password could not be verified.";
    public static final String FIRST_NAME_REQUIRED = "First name is required.";
    public static final String DUPLICATE_USERNAME_ERROR = "This username already exists.";
    public static final String WELCOME_MESSAGE = "Welcome";
    public static final String SUCCESS_MESSAGE = "Your account was created successfully. You are now logged in.";
    public static final String REGISTRATION_SUCCESS_MESSAGE = "Your account was created successfully. You are now logged in.";
    public static final String INTERNAL_ERROR_MESSAGE = "An internal error has occurred and has been logged.";
    public static final String USERNAME_PASSWORD_REQUIRED_MESSAGE = "Please enter a username and password.";
    public static final String ACCOUNT_OPENED_TITLE = "Account Opened!";
    public static final String ACCOUNT_OPENED_MESSAGE = "Congratulations, your account is now open.";

    // Transfer Funds Error Messages
    public static final String SELECT_FROM_ACCOUNT_MSG = "Please choose an account to transfer from.";
    public static final String SELECT_TO_ACCOUNT_MSG = "Please choose an account to transfer to.";
    public static final String ENTER_AMOUNT_MSG = "Please enter a numeric value in the amount field.";
    public static final String SAME_ACCOUNT_ERROR = "From and To accounts must be different.";
    public static final String INSUFFICIENT_FUNDS_ERROR = "Insufficient funds in account.";
    public static final String TRANSFER_SUCCESS_MESSAGE = "Transfer Complete!";
    public static final String INVALID_AMOUNT_ERROR = "The amount must be a number.";
    public static final String NEGATIVE_AMOUNT_ERROR = "The amount cannot be negative or zero.";

    // Open Account Success Messages
    public static final String ACCOUNT_OPENED_HEADING = "Account Opened!";
    public static final String ACCOUNT_OPENED_SUCCESS_MESSAGE = "Congratulations, your account is now open.";
    public static final String ACCOUNT_SUCCESS_MESSAGE = "Your new account was successfully opened.";

    // Registration - Valid Data
    public static final String VALID_FIRST_NAME = "Mark";
    public static final String VALID_LAST_NAME = "Emad";
    public static final String VALID_ADDRESS = "123 Cairo St";
    public static final String VALID_CITY = "Cairo";
    public static final String VALID_STATE = "Cairo";
    public static final String VALID_ZIP = "477771";
    public static final String VALID_PHONE = "01234567899";
    public static final String VALID_SSN = "123456789";
    public static final String VALID_REG_USERNAME = "Mark123";
    public static final String VALID_REG_PASSWORD = "Mark123456";

    // Registration - Invalid Data
    public static final String INVALID_FIRST_NAME = "";
    public static final String INVALID_LAST_NAME = "";
    public static final String INVALID_ADDRESS = "";
    public static final String INVALID_CITY = "";
    public static final String INVALID_STATE = "";
    public static final String INVALID_ZIP = "01";
    public static final String INVALID_PHONE = "012345";
    public static final String INVALID_SSN = "12345";
    public static final String INVALID_REG_USERNAME = "Mark@";
    public static final String INVALID_REG_PASSWORD = "123";
    public static final String INVALID_CONFIRM_PASSWORD = "12";

    // TransferFunds data — Replace with real account numbers after login
    public static final String FROM_ACCOUNT = "13344";
    public static final String TO_ACCOUNT = "13344";
    public static final String TRANSFER_AMOUNT = "100";

    // OpenAccount data
    public static final String VALID_ACCOUNT_TYPE = "CHECKING";
    public static final String VALID_SOURCE_ACCOUNT = "13344";

    // Bill Pay - Valid Payee Info
    public static final String PAYEE_NAME = "Ali Ahmed";
    public static final String PAYEE_ADDRESS = "456 Street";
    public static final String PAYEE_CITY = "Giza";
    public static final String PAYEE_STATE = "Giza";
    public static final String PAYEE_ZIP = "11311";
    public static final String PAYEE_PHONE = "01001122334";
    public static final String PAYEE_AMOUNT = "250";

    // Expected Confirmation Text
    public static final String BILL_PAYMENT_SUCCESS_MSG = "Bill Payment Complete";




    // Timeouts
    public static final long EXPLICIT_WAIT = 15;
    public static final long VISUAL_INSPECTION_WAIT = 5;
    public static final boolean VISUAL_INSPECTION_ON_FAILURE = true;

    public static final String ACCOUNT_NUMBER = "13344";

    public static final String UPDATE_CONTACT_INFO_URL = "https://parabank.parasoft.com/parabank/updateprofile.htm";

}