package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.AccountOverviewPage;
import pages.LoginPage;
import pages.RegistrationPage;
import utils.Constants;

public class RegistrationTests extends BaseTest {

    @Test(priority = 5)
    public void testNavigateToRegistration() {
        goToHomePage();

        LoginPage loginPage = new LoginPage(driver);
        RegistrationPage registrationPage = loginPage.navigateToRegistration();

        Assert.assertTrue(registrationPage.isRegistrationFormDisplayed(),
                "Registration page did not load.");
    }

    @Test(priority = 6)
    public void testValidRegistration() {
        goToRegistrationPage();

        RegistrationPage registrationPage = new RegistrationPage(driver);
        AccountOverviewPage accountPage = registrationPage.register(
                Constants.VALID_FIRST_NAME,
                Constants.VALID_LAST_NAME,
                Constants.VALID_ADDRESS,
                Constants.VALID_CITY,
                Constants.VALID_STATE,
                Constants.VALID_ZIP,
                Constants.VALID_PHONE,
                Constants.VALID_SSN,
                Constants.VALID_REG_USERNAME,
                Constants.VALID_REG_PASSWORD,
                Constants.VALID_REG_PASSWORD
        );

        dismissPopup(); // Dismiss any browser alerts

        // ✅ Now uses the correct method from AccountOverviewPage
        Assert.assertTrue(accountPage.isRegistrationSuccessMessageDisplayed(),
                "Welcome message did not appear after registration.");
    }

    @Test(priority = 7)
    public void testMissingFields_ShowFirstNameError() {
        goToRegistrationPage();

        RegistrationPage registrationPage = new RegistrationPage(driver);

        registrationPage.register(
                Constants.INVALID_FIRST_NAME,
                Constants.VALID_LAST_NAME,
                Constants.VALID_ADDRESS,
                Constants.VALID_CITY,
                Constants.VALID_STATE,
                Constants.VALID_ZIP,
                Constants.VALID_PHONE,
                Constants.VALID_SSN,
                Constants.VALID_REG_USERNAME,
                Constants.VALID_REG_PASSWORD,
                Constants.VALID_REG_PASSWORD
        );

        String errorMessage = registrationPage.getFirstNameError();
        Assert.assertTrue(errorMessage.contains(Constants.FIRST_NAME_REQUIRED),
                "Expected: '" + Constants.FIRST_NAME_REQUIRED + "' but got: '" + errorMessage + "'");
    }

    @Test(priority = 8)
    public void testDuplicateUsernameError() {
        goToRegistrationPage();

        RegistrationPage registrationPage = new RegistrationPage(driver);

        registrationPage.register(
                Constants.VALID_FIRST_NAME,
                Constants.VALID_LAST_NAME,
                Constants.VALID_ADDRESS,
                Constants.VALID_CITY,
                Constants.VALID_STATE,
                Constants.VALID_ZIP,
                Constants.VALID_PHONE,
                Constants.VALID_SSN,
                Constants.VALID_REG_USERNAME, // Known duplicate
                Constants.VALID_REG_PASSWORD,
                Constants.VALID_REG_PASSWORD
        );

        String errorMessage = registrationPage.getUsernameError();
        Assert.assertTrue(errorMessage.contains(Constants.DUPLICATE_USERNAME_ERROR),
                "Expected: '" + Constants.DUPLICATE_USERNAME_ERROR + "' but got: '" + errorMessage + "'");
    }
}