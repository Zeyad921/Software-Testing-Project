package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoginPage;
import utils.Constants;
import pages.AccountOverviewPage;

public class LoginTests extends BaseTest {

    @Test(priority = 1)
    public void testValidLogin() {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        AccountOverviewPage accountPage = loginPage.loginSuccessfully(
                Constants.VALID_USERNAME,
                Constants.VALID_PASSWORD
        );

        Assert.assertTrue(accountPage.isPageLoaded(), "Account Overview page did not load.");
        Assert.assertTrue(accountPage.isLogoutLinkDisplayed(), "Logout link not found after login.");
    }

    @Test(dataProvider = "invalidCredentials", priority = 2)
    public void testInvalidLogin(String username, String password) {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginWithInvalidCredentials(username, password);

        try {
            // Check if the error message is displayed
            if (loginPage.verifyTextContainsError(Constants.ERROR_MESSAGE)) {
                System.out.println("Invalid credentials error message detected - marking test as passed");
                return; // Test passes when it sees the expected error message
            }

            // If internal error is displayed, also mark as passed
            if (loginPage.verifyTextContainsError(Constants.INTERNAL_ERROR_MESSAGE)) {
                System.out.println("Internal error message detected - marking test as passed");
                return;
            }

            // If we get here, none of the expected error messages were found
            Assert.fail("Neither invalid credentials nor internal error message was displayed");

        } catch (Exception e) {
            System.out.println("Exception in invalid login test: " + e.getMessage());

            // Log current page state
            System.out.println("Current page source: " + driver.getPageSource().substring(0, Math.min(500, driver.getPageSource().length())) + "...(truncated)");

            // Re-throw to fail the test
            throw e;
        }
    }

    @Test(priority = 3)
    public void testBlankFields() {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginWithInvalidCredentials("", "");

        // ✅ Use Constants for expected message
        Assert.assertTrue(loginPage.verifyTextContainsError(Constants.USERNAME_PASSWORD_REQUIRED_MESSAGE),
                "Expected 'Please enter a username and password.' message");
    }

    @Test(priority = 4)
    public void testErrorMessage() {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginWithInvalidCredentials("invalid", "invalid");

        try {
            // Check if the error message is displayed
            if (loginPage.verifyTextContainsError(Constants.ERROR_MESSAGE)) {
                System.out.println("Invalid credentials error message detected - marking test as passed");
                return; // Test passes when it sees the expected error message
            }

            // If internal error is displayed, also mark as passed
            if (loginPage.verifyTextContainsError(Constants.INTERNAL_ERROR_MESSAGE)) {
                System.out.println("Internal error message detected - marking test as passed");
                return;
            }

            // If we get here, none of the expected error messages were found
            Assert.fail("Neither invalid credentials nor internal error message was displayed");

        } catch (Exception e) {
            System.out.println("Exception in error message test: " + e.getMessage());

            // Log current page state
            System.out.println("Current page source: " + driver.getPageSource().substring(0, Math.min(500, driver.getPageSource().length())) + "...(truncated)");

            // Re-throw to fail the test
            throw e;
        }
    }

    @DataProvider(name = "invalidCredentials")
    public Object[][] invalidData() {
        return new Object[][]{
                {Constants.INVALID_USERNAME, Constants.VALID_PASSWORD},
                {Constants.VALID_USERNAME, Constants.INVALID_PASSWORD}
        };
    }
}