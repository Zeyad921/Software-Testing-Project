package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.AccountOverviewPage;
import pages.LoginPage;
import pages.OpenAccountPage;
import utils.Constants;

public class OpenAccountTests extends BaseTest {

    @Test(priority = 12)
    public void testNavigateToOpenAccountPage() {
        driver.get(Constants.BASE_URL);

        // Login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginSuccessfully(Constants.VALID_USERNAME, Constants.VALID_PASSWORD);

        // Navigate to Open Account page
        OpenAccountPage openAccountPage = new OpenAccountPage(driver);
        driver.get(Constants.OPEN_ACCOUNT_URL);

        // Assert that the Open Account page is loaded
        Assert.assertTrue(openAccountPage.isPageLoaded(),
                "Not on Open Account page.");
    }

    @Test(priority = 13)
    public void testOpenNewCheckingAccount() {
        driver.get(Constants.BASE_URL);

        // Login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginSuccessfully(Constants.VALID_USERNAME, Constants.VALID_PASSWORD);

        // Navigate to Open Account page
        OpenAccountPage openAccountPage = new OpenAccountPage(driver);
        driver.get(Constants.OPEN_ACCOUNT_URL);

        // Assert that the Open Account page is loaded
        Assert.assertTrue(openAccountPage.isPageLoaded(), "Open Account page did not load.");

        // Get an existing account ID from the Account Overview page
        AccountOverviewPage accountOverviewPage = new AccountOverviewPage(driver);
        driver.get(Constants.ACCOUNTS_OVERVIEW_URL);
        String existingAccountId = accountOverviewPage.getAccountNumberFromPage();
        System.out.println("Using existing account ID for funding: " + existingAccountId);

        // Navigate back to open account page and open a new SAVINGS account
        driver.get(Constants.OPEN_ACCOUNT_URL);
        String newAccountId = openAccountPage.openNewAccount("SAVINGS", existingAccountId);
        System.out.println("New account created with ID: " + newAccountId);

        // Check for success message after account creation
        boolean isSuccess = openAccountPage.isAccountOpenedSuccessfully();
        Assert.assertTrue(isSuccess, "Account success message not displayed");

        // Verify account ID was returned
        Assert.assertFalse(newAccountId.isEmpty(), "No account ID was returned after account creation");

        // Log the success message for verification
        String successMessage = openAccountPage.getSuccessMessageText();
        System.out.println("Success message: " + successMessage);

        // Optional assertion: verify success message contains expected text
        // Use more flexible assertion with contains() rather than exact matching
        boolean hasSuccessText =
                successMessage.contains("Account Opened") ||
                        successMessage.contains("Congratulations") ||
                        successMessage.contains("Your new account");

        Assert.assertTrue(hasSuccessText,
                "Success message did not contain expected text. Actual: " + successMessage);
    }

    @Test(priority = 14)
    public void testVerifyNewAccountInOverview() {
        driver.get(Constants.BASE_URL);

        // Login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginSuccessfully(Constants.VALID_USERNAME, Constants.VALID_PASSWORD);

        // Get an existing account ID from the Account Overview page
        AccountOverviewPage accountOverviewPage = new AccountOverviewPage(driver);
        driver.get(Constants.ACCOUNTS_OVERVIEW_URL);
        String existingAccountId = accountOverviewPage.getAccountNumberFromPage();
        System.out.println("Using existing account ID for funding: " + existingAccountId);

        // Navigate to Open Account page and open a new account
        OpenAccountPage openAccountPage = new OpenAccountPage(driver);
        driver.get(Constants.OPEN_ACCOUNT_URL);
        Assert.assertTrue(openAccountPage.isPageLoaded(), "Open Account page did not load.");

        String newAccountId = openAccountPage.openNewAccount("SAVINGS", existingAccountId);
        System.out.println("Created account with ID: " + newAccountId);

        // Navigate to Accounts Overview page to verify the new account
        driver.get(Constants.ACCOUNTS_OVERVIEW_URL);
        accountOverviewPage = new AccountOverviewPage(driver);
        Assert.assertTrue(accountOverviewPage.isPageLoaded(), "Accounts Overview page did not load.");

        // Check if the new account is listed
        Assert.assertTrue(accountOverviewPage.isAccountListed(newAccountId),
                "New account " + newAccountId + " not found in overview.");
    }
}