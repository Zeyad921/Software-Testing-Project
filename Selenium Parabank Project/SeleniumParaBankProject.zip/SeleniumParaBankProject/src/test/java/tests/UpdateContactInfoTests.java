package tests;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.UpdateContactInfoPage;
import utils.Constants;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class UpdateContactInfoTests extends BaseTest {

    private UpdateContactInfoPage navigateToUpdatePage() {
        driver.get(Constants.BASE_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginSuccessfully(Constants.VALID_USERNAME, Constants.VALID_PASSWORD);

        driver.get(Constants.UPDATE_CONTACT_INFO_URL);
        return new UpdateContactInfoPage(driver);
    }

    private void takeScreenshot(String fileName) {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            Files.copy(src.toPath(), new File("./screenshots/" + fileName + ".png").toPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 21)
    public void testNavigateToUpdateContactInfoPage() {
        UpdateContactInfoPage updatePage = navigateToUpdatePage();
        Assert.assertTrue(updatePage.isPageLoaded(), "Update Contact Info page did not load.");
    }

    @Test(priority = 22)
    public void testUpdateAddressAndPhoneNumber() {
        UpdateContactInfoPage updatePage = navigateToUpdatePage();
        updatePage.updateContactInfo("123 Main St", "Springfield", "IL", "62704", "5551234567");

        if (!updatePage.isUpdateSuccessMessageDisplayed()) {
            System.out.println("Success message NOT found!");
            System.out.println("Current URL: " + driver.getCurrentUrl());
            System.out.println("Page Source:\n" + driver.getPageSource());
            takeScreenshot("update_failure");
        }

        Assert.assertTrue(updatePage.isUpdateSuccessMessageDisplayed(),
                "Update success message was not displayed.");
    }

    @Test(priority = 23)
    public void testSubmitWithEmptyMandatoryFields() {
        UpdateContactInfoPage updatePage = navigateToUpdatePage();
        updatePage.updateContactInfo("", "", "", "", "");

        if (!updatePage.isValidationMessageDisplayed()) {
            System.out.println("Validation message NOT found!");
            takeScreenshot("validation_failure");
        }

        Assert.assertTrue(updatePage.isValidationMessageDisplayed(),
                "Validation message was not displayed for empty mandatory fields.");
    }
}