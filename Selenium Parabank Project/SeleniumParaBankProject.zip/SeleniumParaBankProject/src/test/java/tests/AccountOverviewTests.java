package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.AccountDetailsPage;
import pages.AccountOverviewPage;
import pages.LoginPage;
import utils.Constants;

public class AccountOverviewTests extends BaseTest {

    @Test(priority = 9)
    public void testLandingOnAccountsOverviewPage() {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        AccountOverviewPage accountOverviewPage = loginPage.loginSuccessfully(
                Constants.VALID_USERNAME,
                Constants.VALID_PASSWORD
        );

        // Accept any of the valid account pages
        Assert.assertTrue(accountOverviewPage.isPageLoaded(),
                "Failed to load any valid account page after login");
    }

    @Test(priority = 10)
    public void testClickAccountNumberToNavigateToDetails() {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        AccountOverviewPage accountOverviewPage = loginPage.loginSuccessfully(
                Constants.VALID_USERNAME,
                Constants.VALID_PASSWORD
        );

        // Click first account number (or use existing account page)
        AccountDetailsPage accountDetailsPage = accountOverviewPage.clickFirstAccountNumber();

        // Verify account details page loaded
        Assert.assertTrue(accountDetailsPage.isPageLoaded(),
                "Account Details/Activity page did not load");

        // Get account number - either from page or URL
        String accountNumber = accountDetailsPage.getAccountNumberFromPage();

        // For debugging - just check it's not empty
        Assert.assertFalse(accountNumber.isEmpty(),
                "Could not retrieve account number from page");

        // Only check against constant if we have a specific account number to check against
        if (!Constants.ACCOUNT_NUMBER.isEmpty()) {
            Assert.assertEquals(accountNumber, Constants.ACCOUNT_NUMBER,
                    "Account number mismatch in details page");
        }
    }

    @Test(priority = 11)
    public void testVerifyBalanceAndTransactionTable() {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        AccountOverviewPage accountOverviewPage = loginPage.loginSuccessfully(
                Constants.VALID_USERNAME,
                Constants.VALID_PASSWORD
        );

        // Navigate to account details
        AccountDetailsPage accountDetailsPage = accountOverviewPage.clickFirstAccountNumber();

        // Allow for some time for transaction table to fully load
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // Ignore
        }

        // Verify transactions are displayed
        Assert.assertTrue(accountDetailsPage.areTransactionsDisplayed(),
                "Transaction table not displayed");

        // Verify specific transaction is present (Check #1111)
        boolean transactionFound = accountDetailsPage.isTransactionPresent("Check # 1111");

        // If not found with exact format, try alternate format
        if (!transactionFound) {
            transactionFound = accountDetailsPage.isTransactionPresent("Check #1111");
        }

        Assert.assertTrue(transactionFound,
                "Expected transaction 'Check # 1111' not found");
    }
}