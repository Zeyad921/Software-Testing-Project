package tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import utils.Constants;

import java.time.Duration;

public class BaseTest {
    protected WebDriver driver;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterMethod
    public void tearDown() {
        try {
            Thread.sleep(Constants.VISUAL_INSPECTION_WAIT * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            if (driver != null) {
                driver.quit();
            }
        }
    }

    protected void dismissPopup() {
        try {
            driver.switchTo().alert().dismiss();
        } catch (Exception ignored) {}
    }

    protected void goToHomePage() {
        driver.get(Constants.BASE_URL);
    }

    protected void goToRegistrationPage() {
        driver.get(Constants.REGISTER_URL);
    }
}