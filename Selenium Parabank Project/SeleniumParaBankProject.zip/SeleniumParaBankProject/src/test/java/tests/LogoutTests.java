package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;
import utils.Constants;

public class LogoutTests extends BaseTest {

    // TC24: Verify logout redirects to login page
    @Test(priority = 24)
    public void verifyLogoutRedirectsToLoginPage() {
        // 1. Login
        driver.get(Constants.BASE_URL);
        LoginPage loginPage = new LoginPage(driver);
        AccountOverviewPage accountPage = loginPage.loginSuccessfully(
                Constants.VALID_USERNAME,
                Constants.VALID_PASSWORD);

        // 2. Initiate logout
        LogoutPage logoutPage = new LogoutPage(driver);
        LoginPage postLogoutPage = logoutPage.performLogout();

        // 3. Verify redirection
        Assert.assertTrue(postLogoutPage.isUsernameFieldDisplayed(),
                "Username field should be visible after logout");
        Assert.assertTrue(postLogoutPage.isPasswordFieldDisplayed(),
                "Password field should be visible after logout");
        Assert.assertTrue(driver.getCurrentUrl().contains("index.htm"),
                "Should redirect to login page after logout");
    }

    // TC25: Verify protected pages redirect to login after logout
    @Test(priority = 25)
    public void verifyProtectedPagesRedirectAfterLogout() {
        // 1. Login and then logout
        driver.get(Constants.BASE_URL);
        new LoginPage(driver).loginSuccessfully(
                Constants.VALID_USERNAME,
                Constants.VALID_PASSWORD);
        new LogoutPage(driver).performLogout();

        // 2. Test access to protected pages
        String[] protectedPages = {
                "overview.htm",
                "transfer.htm",
                "activity.htm",
                "openaccount.htm"
        };

        for (String page : protectedPages) {
            driver.get(Constants.BASE_URL + page);

            LoginPage loginPage = new LoginPage(driver);
            Assert.assertTrue(loginPage.isUsernameFieldDisplayed(),
                    "Should redirect to login when accessing " + page);
            Assert.assertTrue(driver.getCurrentUrl().contains("index.htm"),
                    "URL should be login page after accessing " + page);
        }
    }
}