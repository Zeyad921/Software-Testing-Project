package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.AccountOverviewPage;
import pages.BillPayPage;
import pages.LoginPage;
import utils.Constants;

public class BillPayTests extends BaseTest {

    @Test(priority = 18)
    public void testNavigateToBillPayPage() {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        AccountOverviewPage accountOverviewPage =
                loginPage.loginSuccessfully(Constants.VALID_USERNAME, Constants.VALID_PASSWORD);

        accountOverviewPage.clickBillPay();

        String expectedUrl = "https://parabank.parasoft.com/parabank/billpay.htm";
        String actualUrl = driver.getCurrentUrl();

        Assert.assertEquals(actualUrl, expectedUrl, "Did not navigate to the expected Bill Pay page URL.");
    }


    @Test(priority = 19)
    public void testValidBillPayment() {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        AccountOverviewPage accountOverviewPage =
                loginPage.loginSuccessfully(Constants.VALID_USERNAME, Constants.VALID_PASSWORD);

        BillPayPage billPayPage = accountOverviewPage.clickBillPay();

        billPayPage.fillBillPaymentForm(
                Constants.PAYEE_NAME,
                Constants.PAYEE_ADDRESS,
                Constants.PAYEE_CITY,
                Constants.PAYEE_STATE,
                Constants.PAYEE_ZIP,
                Constants.PAYEE_PHONE,
                Constants.ACCOUNT_NUMBER,
                Constants.PAYEE_AMOUNT
        );

        billPayPage.submitPayment();

        Assert.assertTrue(
                billPayPage.getConfirmationMessage().contains(Constants.BILL_PAYMENT_SUCCESS_MSG),
                "Payment confirmation message not shown."
        );
    }


    @Test(priority = 20)
    public void testEmptyBillPaymentFormShowsErrors() {
        driver.get(Constants.BASE_URL);

        LoginPage loginPage = new LoginPage(driver);
        AccountOverviewPage accountOverviewPage =
                loginPage.loginSuccessfully(Constants.VALID_USERNAME, Constants.VALID_PASSWORD);

        BillPayPage billPayPage = accountOverviewPage.clickBillPay();

        // اترك الحقول فاضية
        billPayPage.fillBillPaymentForm("", "", "", "", "", "", "", "");

        billPayPage.submitPayment();

        Assert.assertTrue(billPayPage.isErrorMessageDisplayed(), "Expected error messages were not displayed.");
    }
}
